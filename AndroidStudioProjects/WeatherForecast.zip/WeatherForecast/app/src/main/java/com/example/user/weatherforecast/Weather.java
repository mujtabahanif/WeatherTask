package com.example.user.weatherforecast;

/**
 * Created by User on 13/05/2017.
 */

public class Weather {

    public Integer id;
    public String main;
    public String description;
    public String icon;




    public Weather()
    {


    }


    private void setId(Integer weatherid)
    {

        id = weatherid;

    }


    private Integer getId()
    {
        return id;
    }


    private void setMain(String weathermain){

        main = weathermain;

    }


    private String getMain()
    {
        return main;

    }


    private void setDescription(String weatherdescription){

        description=weatherdescription;
    }


    private String getDescription()
    {
        return description;

    }


    private void setIcon(String weathericon){

        icon = weathericon;
    }


    private String getIcon(){

        return icon;

    }


}
