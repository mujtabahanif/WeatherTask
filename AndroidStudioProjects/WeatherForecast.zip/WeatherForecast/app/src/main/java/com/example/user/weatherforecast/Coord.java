package com.example.user.weatherforecast;

/**
 * Created by User on 13/05/2017.
 */

public class Coord {

  public double lon;
    public double lat;

    public void Coord(){


    }


    private void setLon(double newlon)
    {

        lon = newlon;
    }

    private double getLon(){

        return lon;
    }


    private void setLat(double newlat){

        lat = newlat;

    }


    private double getLat(){

        return lat;
    }




}





