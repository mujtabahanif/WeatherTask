package com.example.user.weatherforecast;

/**
 * Created by User on 13/05/2017.
 */

public class Wind {


    public double speed;
    public double deg;


    public Wind(){


    }

    private void setSpeed(double newSpeed){

        speed = newSpeed;
    }


    private double getSpeed(){

        return speed;
    }


    private void setdeg(Double newdegree){

        deg = newdegree;

    }

    private double getDeg (){

        return deg;
    }



}
