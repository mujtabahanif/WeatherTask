package com.example.user.weatherforecast;

/**
 * Created by User on 13/05/2017.
 */

public class MainObject {

    double temp;
    double temp_min;
    double temp_max;
    double pressure;
    double sea_level;
    double grnd_level;
    Integer humidity;
    double temp_kf;


    public MainObject() {


    }


    private void settemp(double newTemp){

        temp = newTemp;

    }


    private double getTemp(){

        return temp;

    }


    private void setTemp_min(double newTempMin){

        temp_min = newTempMin;

    }

    private double getTemp_min(){

        return temp_min;

    }


    private void setTemp_max(double newTempMax){

        temp_max = newTempMax;

    }


    private double getTemp_max()
    {

        return temp_max;
    }


    private void setPressure(double newPressure){

        pressure = newPressure;

    }

    private double getPressure(){

        return pressure;

    }

    private void setSeaLevel(double newSeaLevel ){

        sea_level = newSeaLevel;

    }

    private double getSeaLevel(){

        return sea_level;

    }

    private void setGroundLevel(double newGroundLevel){

        grnd_level = newGroundLevel;

    }

    private double getGroundLevel(){

        return grnd_level;
    }

    private void setHumidity(Integer newHumidity){

        humidity = newHumidity;

    }

    private Integer getHumidity(){

        return humidity;
    }

    private void setTemp_kf(Double newTemp_kf){

        temp_kf =  newTemp_kf;
    }


    private Double getTemp_kf(){

        return temp_kf;

    }

}
