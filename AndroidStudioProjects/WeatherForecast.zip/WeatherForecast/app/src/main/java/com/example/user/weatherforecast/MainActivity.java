package com.example.user.weatherforecast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import java.util.ArrayList;
import java.util.List;

import static com.example.user.weatherforecast.R.id.spinner;

public class MainActivity extends AppCompatActivity  implements
        OnItemSelectedListener {
    Spinner spinner,spinnerCities;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.countries_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinnerCities = (Spinner) findViewById(R.id.spinnerCities);
        ArrayAdapter<CharSequence> adapterCities = ArrayAdapter.createFromResource(
                this, R.array.Afghanistan_cities, android.R.layout.simple_spinner_item);
        adapterCities.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCities.setAdapter(adapterCities);


        spinner.setOnItemSelectedListener(this);
    }
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                               long arg3) {
        // TODO Auto-generated method stub
       SetSpinnerCities(spinner, spinnerCities);



    }


    public void SetSpinnerCities(Spinner countriesSpinner, Spinner citiesSpinner) {

        String selectedCountry = countriesSpinner.getSelectedItem().toString();


        switch(selectedCountry) {

            case "Afganistan":
                ArrayAdapter<CharSequence> adapterCitiesAfghanistan = ArrayAdapter.createFromResource(
                        this, R.array.Afghanistan_cities, android.R.layout.simple_spinner_item);
                adapterCitiesAfghanistan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesAfghanistan.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesAfghanistan);

                break;


            case "Albenia":
                ArrayAdapter<CharSequence> adapterCitiesAlbenia = ArrayAdapter.createFromResource(
                        this, R.array.Albenia_cities, android.R.layout.simple_spinner_item);
                adapterCitiesAlbenia.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesAlbenia.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesAlbenia);

                break;


            case "Algeria":
                ArrayAdapter<CharSequence> adapterCitiesAlgeria = ArrayAdapter.createFromResource(
                        this, R.array.Algeria_cities, android.R.layout.simple_spinner_item);
                adapterCitiesAlgeria.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesAlgeria.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesAlgeria);

                break;

            case "Austria":
                ArrayAdapter<CharSequence> adapterCitiesAustria = ArrayAdapter.createFromResource(
                        this, R.array.Austria_cities, android.R.layout.simple_spinner_item);
                adapterCitiesAustria.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesAustria.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesAustria);
                break;

            case "Azerbaijan":
                ArrayAdapter<CharSequence> adapterCitiesAzerbaijan = ArrayAdapter.createFromResource(
                        this, R.array.Azerbaijan_cities, android.R.layout.simple_spinner_item);
                adapterCitiesAzerbaijan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesAzerbaijan.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesAzerbaijan);

                break;


            case "Bahamas":
                ArrayAdapter<CharSequence> adapterCitiesBahamas = ArrayAdapter.createFromResource(
                        this, R.array.Bahamas_cities, android.R.layout.simple_spinner_item);
                adapterCitiesBahamas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesBahamas.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesBahamas);

                break;


            case "Bangladesh":
                ArrayAdapter<CharSequence> adapterCitiesBangladesh = ArrayAdapter.createFromResource(
                        this, R.array.Bangladesh_cities, android.R.layout.simple_spinner_item);
                adapterCitiesBangladesh.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesBangladesh.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesBangladesh);

                break;

            case "Barbados":
                ArrayAdapter<CharSequence> adapterCitiesBarbados = ArrayAdapter.createFromResource(
                        this, R.array.Barbados_cities, android.R.layout.simple_spinner_item);
                adapterCitiesBarbados.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesBarbados.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesBarbados);

                break;

            case "Brazil":
                ArrayAdapter<CharSequence> adapterCitiesBrazil = ArrayAdapter.createFromResource(
                        this, R.array.Brazil_cities, android.R.layout.simple_spinner_item);
                adapterCitiesBrazil.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesBrazil.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesBrazil);

                break;

            case "Cambodia":
                ArrayAdapter<CharSequence> adapterCitiesCambodia = ArrayAdapter.createFromResource(
                        this, R.array.Cambodia_cities, android.R.layout.simple_spinner_item);
                adapterCitiesCambodia.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesCambodia.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesCambodia);
                break;

            case "Cameroon":
                ArrayAdapter<CharSequence> adapterCitiesCameroon = ArrayAdapter.createFromResource(
                        this, R.array.Cameroon_cities, android.R.layout.simple_spinner_item);
                adapterCitiesCameroon.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesCameroon.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesCameroon);
                break;

            case "Canada":
                ArrayAdapter<CharSequence> adapterCitiesCanada = ArrayAdapter.createFromResource(
                        this, R.array.Canada_cities, android.R.layout.simple_spinner_item);
                adapterCitiesCanada.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesCanada.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesCanada);

                break;


            case "Greece":
                ArrayAdapter<CharSequence> adapterCitiesGreece = ArrayAdapter.createFromResource(
                        this, R.array.Greece_cities, android.R.layout.simple_spinner_item);
                adapterCitiesGreece.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesGreece.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesGreece);

                break;

            case "Hungary":
                ArrayAdapter<CharSequence> adapterCitiesHungary = ArrayAdapter.createFromResource(
                        this, R.array.Hungary_cities, android.R.layout.simple_spinner_item);
                adapterCitiesHungary.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesHungary.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesHungary);

                break;

            case "Iceland":
                ArrayAdapter<CharSequence> adapterCitiesIceland = ArrayAdapter.createFromResource(
                        this, R.array.Iceland_cities, android.R.layout.simple_spinner_item);
                adapterCitiesIceland.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesIceland.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesIceland);

                break;

            case "Israel":
                ArrayAdapter<CharSequence> adapterCitiesIsrael = ArrayAdapter.createFromResource(
                        this, R.array.Israel_cities, android.R.layout.simple_spinner_item);
                adapterCitiesIsrael.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesIsrael.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesIsrael);

                break;


            case "Italy":
                ArrayAdapter<CharSequence> adapterCitiesItaly = ArrayAdapter.createFromResource(
                        this, R.array.Italy_cities, android.R.layout.simple_spinner_item);
                adapterCitiesItaly.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesItaly.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesItaly);

                break;



            case "UK":
                ArrayAdapter<CharSequence> adapterCitiesUK = ArrayAdapter.createFromResource(
                        this, R.array.UK_cities, android.R.layout.simple_spinner_item);
                adapterCitiesUK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesUK.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesUK);

                break;


            case "US":
                ArrayAdapter<CharSequence> adapterCitiesUS = ArrayAdapter.createFromResource(
                        this, R.array.US_cities, android.R.layout.simple_spinner_item);
                adapterCitiesUS.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                adapterCitiesUS.notifyDataSetChanged();
                citiesSpinner.setAdapter(adapterCitiesUS);

                break;



        }

    }


    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }




    }

